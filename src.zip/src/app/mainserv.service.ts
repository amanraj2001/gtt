import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainservService {

  constructor(private http:HttpClient) { }


  login(log:any):Observable<any>{
    return this.http.post("https://localhost:7280/api/user1/login",log)
  }

  // reg(regis:any,header:any):Observable<any>{
  //   return this.http.post("https://localhost:7280/api/user1/Registeruser",{header},regis)
  // }
  // getdata():Observable<any>{
  //   return this.http.get("https://localhost:7280/api/user1/getlist")
  // }
}


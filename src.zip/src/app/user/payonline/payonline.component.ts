import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MainservService } from 'src/app/mainserv.service';

@Component({
  selector: 'app-payonline',
  templateUrl: './payonline.component.html',
  styleUrls: ['./payonline.component.css']
})
export class PayonlineComponent {

  payform!:FormGroup;

  paymethod=['Upi','']
  constructor(private demo:MainservService,private fb:FormBuilder,private http:HttpClient) {
    this.payform=this.fb.group({
      Paymentamount:[''],

      Paymentmethod:[''],
      otp:['']
    })
  }
  btn(data:any){
    var id = localStorage.getItem('id');
    this.http.post<any>("https://localhost:7280/api/user1/enterpayment/"+id,data).subscribe(
      response=>{
        console.log(response);
        console.log("ok");


      },
      error=>{
        console.log(error);

      }
    )

  }

}

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MainservService } from 'src/app/mainserv.service';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit{


  constructor(private demo:MainservService,private http:HttpClient) {


  }
arr:any=[]
  ngOnInit(): void {
    var id  = localStorage.getItem('id')
      this.http.get("https://localhost:7280/api/user1/getpayment/"+id).subscribe(
        response=>{
          console.log(response);
          this.arr = response;
          console.log("ook");


        },
        error=>{
          console.log(error);

        }

      )
  }
}

export interface data{
  Firstname:string;
  middlename:string;
  lastname:string;

  image:string;
  flatnumber:string;
  area:string;
  state:string;
  city:string;
  pincode:number;
  useremail:string;

}


export interface logg{
  Username:string;
  Userpass:string;
}

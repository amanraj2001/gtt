import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MainservService } from 'src/app/mainserv.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit{

  arr:any=[]
  p:any;
constructor(private demo:MainservService,private http:HttpClient) {

}
  ngOnInit(): void {
    // this.demo.getdata().subscribe(p=>{
    //   console.log(p);
    //   this.arr=p
    //   console.log(this.arr);

    // })
    var c = localStorage.getItem('token')
    console.log(c);

    const token = c;
    const headers = new HttpHeaders().set('Authorization',`Bearer ${token}`)

    this.http.get("https://localhost:7280/api/user1/getlist",{headers}).subscribe(
      response=>{
        console.log(response);
        this.arr=response;
      },
      error=>{
        console.error(error)
      }

    )
  }


  Delete(i:number){
    var c = localStorage.getItem('token')
    console.log(c);
    console.log(i);


    const token = c;
    const headers = new HttpHeaders().set('Authorization',`Bearer ${token}`)

      this.http.delete("https://localhost:7280/api/user1/"+i,{headers}).subscribe(
        response=>{
          console.log(response);

        },
        error=>{
          console.error(error);
          console.log("hh");

        }
      )
  }

}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MainservService } from 'src/app/mainserv.service';
import { data, logg } from '../models/data';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {


    logform!:FormGroup;
    constructor(private demo:MainservService,private fb:FormBuilder,private route:Router){
      this.logform = this.fb.group({
        Username:['',Validators.required],
        Userpass:['',Validators.required]
      })
    }

    get uname(){
      return this.logform.get('Username')
    }

    get upass(){
      return this.logform.get('Userpass')
    }


    sub(s:logg){


      this.demo.login(s).subscribe(x=>{
        if(x==null){
console.log("error");

        }
        else{

          console.log(x);
          localStorage.setItem('id',x.user.devoteeid);
          localStorage.setItem('token',x.token)
          console.log(x.user.roleid);

          if(x.user.roleid==1){

            this.route.navigate(['home'])
          }
          else{
            this.route.navigate(['userhome'])
          }
        }
      })
    }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PayonlineComponent } from '../user/payonline/payonline.component';
import { UserpageComponent } from '../user/userpage/userpage.component';
import { AdduserComponent } from './adduser/adduser.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';

const routes: Routes = [
  {
    path: '',
    component: NavbarComponent,
    children: [
      {
        path: '',
        component: LoginComponent,
      },
      {path:'home',component:HomepageComponent},
      {path:'adduser',component:AdduserComponent},
      {path:'userhome',component:UserpageComponent},
      {path:'pay',component:PayonlineComponent}
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}

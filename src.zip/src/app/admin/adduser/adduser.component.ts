import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Token } from '@angular/compiler';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainservService } from 'src/app/mainserv.service';
import { data } from '../models/data';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent {
  loginform!:FormGroup;
  constructor(private demo:MainservService,private fb:FormBuilder,private http:HttpClient){
    this.loginform = this.fb.group({

        Firstname:['',Validators.required],
        middlename:['',Validators.required],
        lastname:['',Validators.required],




        flatnumber:['',Validators.required],
        area:['',Validators.required],
        state:['',Validators.required],
        city:['',Validators.required],
        pincode:['',Validators.required],

      useremail:['',Validators.required]

    })
  }


  get first(){
    return this.loginform.get('firstname')
  }
  get middle(){
    return this.loginform.get('middlename')
  }
  get last(){
    return this.loginform.get('lastname')
  }

  get flat(){
    return this.loginform.get('flatnumber')
  }
  get area(){
    return this.loginform.get('area')
  }
  get stat(){
    return this.loginform.get('state')
  }
  get cit(){
    return this.loginform.get('city')
  }
  get pin(){
    return this.loginform.get('pincode')
  }
  get mail(){
    return this.loginform.get('useremail')
  }




  file!:File;
  cng(event:any){
    this.file=event.target.files[0]
    console.log(this.file);

  }

  clc(){
    let myData:data=this.loginform.value;
    var c = localStorage.getItem('token')
    console.log(c);

    const token = c;
    const headers = new HttpHeaders().set('Authorization',`Bearer ${token}`)

    const formdata = new FormData();
    formdata.append('file',this.file);
    this.http.post<any>("https://localhost:7280/api/user1/upload",formdata).subscribe({
      next:(resp:any)=>{
        myData.image=resp.url;
        console.log(resp);
        console.log(resp.url);
        console.log(myData);
        this.http.post("https://localhost:7280/api/user1/Registeruser",myData,{headers}).subscribe(
           respo=>{
            console.log(respo);


            console.log("ok");

           },
           error=>{
            console.log(error)
           }
        )


      },
      error:(err:any)=>{
        console.log(err);

      }


    })

  }
  img(){
    const formdata = new FormData();
    formdata.append('file',this.file);

  }



}

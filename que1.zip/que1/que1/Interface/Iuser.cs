﻿using que1.Models;

namespace que1.Interface
{
    public interface Iuser:Igeneric<User>
    {

    }
}

﻿namespace que1.Interface
{
    public interface Igeneric<T> where T : class
    {
        IEnumerable<T> Getall();
        Task add(T entity);
        Task  Delete(T entity);
        Task update(T entity, int id);
    }
}

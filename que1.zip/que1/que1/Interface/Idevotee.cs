﻿using que1.Models;

namespace que1.Interface
{
    public interface Idevotee:Igeneric<Devotee>
    {
    }
}

﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MimeKit;
using que1.dtos;
using que1.Interface;
using que1.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using MailKit.Net.Smtp;
using System.Data;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace que1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class user1Controller : ControllerBase
    {
        private readonly SpiritualContext _context;
        private readonly Iuser _user;
        private readonly IConfiguration _configure;
        private readonly Idevotee _devotee;
        private readonly Ipayment _payment;

        public user1Controller(SpiritualContext context ,Iuser iuser,IConfiguration configuration,Idevotee idevotee,Ipayment ipayment)
        {
            _context = context;
            _user=iuser;
            _configure = configuration;
            _devotee = idevotee;
            _payment = ipayment;
        }

        [HttpGet]
        public IActionResult getdata()
        {
            var x =  _user.Getall();
            return Ok(x);
        }


        [HttpPost("login")]
        public IActionResult login([FromBody] logindto log)
        {
            if (log == null)
            {
                return BadRequest("no content");
            }
            var user = _context.Users.FirstOrDefault(x=>x.Username==log.Username && x.Userpass==log.Userpass );
            if(user == null)
            {
                return BadRequest("error");
            }
            var token = createtoken(user);
            var resp = new
            {
                user,
                token,
            };
            return Ok(resp);

        }

        //,Authorize(Roles = "1")
        [HttpPost("Registeruser"), Authorize(Roles = "1")]
        public  IActionResult registeruser([FromBody] Registeruser reg)
        {
            Devotee devotee = new Devotee();
            devotee.Firstname = reg.Firstname;
            devotee.Lastname = reg.Lastname;
            devotee.Middlename = reg.Middlename;
            devotee.Image =reg.image ;
            devotee.Flatnumber = reg.Flatnumber;
            devotee.Area = reg.Area;
            devotee.State = reg.State;
            devotee.City = reg.City;
            devotee.Pincode = reg.Pincode;
            devotee.Useremail = reg.Useremail;
            devotee.Initiationdate = DateTime.Now;
            _context.Devotees.Add(devotee);
            _context.SaveChanges();
            
            var devotees = _context.Devotees.FirstOrDefault(x=>x.Firstname == reg.Firstname && x.Lastname== reg.Lastname);
            var user = new User();
            var month = devotee.Initiationdate.Value.Month;
            var year = devotee.Initiationdate.Value.Year;
            user.Devoteeid = devotee.Devoteeid;
            var xyz = devotees.Firstname;
            var len = devotees.Lastname.Length;
            user.Username= year+ xyz.Substring(0,3)+ devotees.Lastname.Substring(len-2,2)+month;
            user.Roleid = 2;
            user.Useremail = reg.Useremail;
            //user.Userpass
            Random random = new Random();
            int x = random.Next(10000, 50000);

            user.Userpass =  x.ToString();
            _context.Users.Add(user);
             _context.SaveChanges();
            var z = sendmail(user.Useremail, user.Username, user.Userpass);
            var resp = new
            {
                url = devotee.Image,
            };
            return Ok(resp);

            //return NoContent();

        }
        private const string SmtpHost = "mail.mailtest.radixweb.net"; // e.g., smtp.gmail.com

        private const int SmtpPort = 465; // e.g., 587 for Gmail

        private const string SmtpUsername = "testdotnet@mailtest.radixweb.net";

        private const string SmtpPassword = "Radix@web#8";
        [HttpPost("mail")]
        public IActionResult sendmail(string recipient, string subject, string body)
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("", SmtpUsername));
            message.To.Add(new MailboxAddress("", recipient));
            message.Subject = subject;


            var bodybuilder = new BodyBuilder();
            bodybuilder.TextBody = body;
            message.Body = bodybuilder.ToMessageBody();


            using (var client = new MailKit.Net.Smtp.SmtpClient())

            {

                client.Connect(SmtpHost, SmtpPort);

                client.Authenticate(SmtpUsername, SmtpPassword);

                client.Send(message);

                client.Disconnect(true);

            }
            return NoContent();
           
     

        }

        public readonly string BKT = "examquee1";
        [HttpPost("upload")]
        public async Task<IActionResult> uploadfile(IFormFile file)
        {
            if(file == null || file.Length<=0) {
                return BadRequest("Error");
            }
            var destkey = $"Images/{file.FileName.ToLower() + DateTime.Now.ToString()}";

            using (var client = new AmazonS3Client(Amazon.RegionEndpoint.APSouth1))
            {
                using (var transferUtility = new TransferUtility(client))
                {
                    var transferUtilityRequest = new TransferUtilityUploadRequest
                    {
                        BucketName = BKT,
                        Key = destkey,
                        InputStream = file.OpenReadStream(),
                    };
                    await transferUtility.UploadAsync(transferUtilityRequest);

                }

            }
            var reg = RegionEndpoint.APSouth1;
            var url = $"https://{BKT}.s3.{reg.SystemName}.amazonaws.com/{destkey}";
            var resp = new
            {
                Message = "File uploaded",
                url
            };
            return Ok(resp);
        }
        

        private string createtoken(User user)
        {
            var sec = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configure.GetSection("Jwt:key").Value));
            var cre = new SigningCredentials(sec, SecurityAlgorithms.HmacSha256);
            var clames = new[]
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role,user.Roleid.ToString())
            };
            var tok = new JwtSecurityToken(_configure.GetSection("Jwt:Issuer").Value, _configure.GetSection("Jwt:Audience").Value, clames,
                expires: DateTime.Now.AddMinutes(12),
                signingCredentials: cre);
            var token = new JwtSecurityTokenHandler().WriteToken(tok);
            return token;
        
        }

        [HttpGet("getlist"),Authorize(Roles = "1")]
        public IActionResult getlist()
        {
            var x = _devotee.Getall();
            return Ok(x);
        }

        [HttpDelete("{id}"), Authorize(Roles = "1")]

        public IActionResult del(int id)
        {
            var user = _context.Devotees.FirstOrDefault(x => x.Devoteeid == id);
            var c = _context.Users.FirstOrDefault(x => x.Devoteeid == user.Devoteeid);
            var t = _context.Payments.FirstOrDefault(x => x.Devoteeid == user.Devoteeid);

          if (user == null)
            {
                return BadRequest("error");
            }
            if (t != null)
            {

                _context.Payments.Remove(t);
                _context.SaveChanges();
            }
            if (c != null)
            {

            _context.Users.Remove(c);
            _context.SaveChanges();
            }

            _context.Devotees.Remove(user);
            _context.SaveChanges();
            return Ok();    

        }

        [HttpPost("getotp/{id}")]

        public IActionResult getotp(int id)
        {
            Random random = new Random();
            var x = random.Next(10000, 50000);
            var y = _context.Devotees.FirstOrDefault(x => x.Devoteeid == id);
            var user = _context.Users.FirstOrDefault(x => x.Devoteeid == y.Devoteeid);
            var z = sendmail(user.Useremail, "otp", x.ToString());
            y.Otp = x;
            _context.Devotees.Add(y);
            _context.SaveChanges();
            return Ok();

        }




        [HttpPost("enterpayment/{id}")]

        public IActionResult pay(int id, [FromBody] payuserdto upay)
        {
            var paydev = _context.Devotees.FirstOrDefault(x => x.Devoteeid == id);
            if (paydev == null)
            {
                return NotFound("user not found");
            }
            Payment payment = new Payment();
            payment.Devoteeid = paydev.Devoteeid;
            payment.Createddata = DateTime.Now;
            payment.Paymentstatus = true;
            payment.Paymentamount = upay.Paymentamount;
            payment.Paymentmethod=upay.Paymentmethod;
            payment.Modifieddate= DateTime.Now;
            var user = _context.Users.FirstOrDefault(x => x.Devoteeid == payment.Devoteeid);

            if ()
            {

                _context.Payments.Add(payment);
            _context.SaveChanges();
        }
            return Ok();


        }

        [HttpGet("getpayment/{id}")]

        public IActionResult payments(int id)
        {
            var x = _payment.Getall();
            var res = from s in x
                      where s.Devoteeid == id
                      select new
                      {
                          s.Paymentamount,
                          s.Paymentmethod,
                          s.Paymentstatus,

                      };
            return Ok(res);
        }


        //[HttpPost("otp")]
        //public IActionResult getpaymentotp()
        //{
            
            
        //}

    }

}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace que1.Models;

public partial class SpiritualContext : DbContext
{
    public SpiritualContext()
    {
    }

    public SpiritualContext(DbContextOptions<SpiritualContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Devotee> Devotees { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=PC0759\\MSSQL2019;Database=spiritual;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Devotee>(entity =>
        {
            entity.HasKey(e => e.Devoteeid).HasName("PK__devotee__3FF3A0CA463E8C13");

            entity.ToTable("devotee");

            entity.Property(e => e.Devoteeid).HasColumnName("devoteeid");
            entity.Property(e => e.Area)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("area");
            entity.Property(e => e.City)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Firstname)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("firstname");
            entity.Property(e => e.Flatnumber)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("flatnumber");
            entity.Property(e => e.Image)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("image");
            entity.Property(e => e.Initiationdate)
                .HasColumnType("datetime")
                .HasColumnName("initiationdate");
            entity.Property(e => e.Lastname)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("lastname");
            entity.Property(e => e.Middlename)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("middlename");
            entity.Property(e => e.Otp).HasColumnName("otp");
            entity.Property(e => e.Pincode).HasColumnName("pincode");
            entity.Property(e => e.State)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("state");
            entity.Property(e => e.Useremail)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("useremail");
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.HasKey(e => e.Paymentid).HasName("PK__payments__AF26EBEEE0AD0BBB");

            entity.ToTable("payments");

            entity.Property(e => e.Paymentid).HasColumnName("paymentid");
            entity.Property(e => e.Createddata)
                .HasColumnType("datetime")
                .HasColumnName("createddata");
            entity.Property(e => e.Devoteeid).HasColumnName("devoteeid");
            entity.Property(e => e.Modifieddate)
                .HasColumnType("datetime")
                .HasColumnName("modifieddate");
            entity.Property(e => e.Paymentamount).HasColumnName("paymentamount");
            entity.Property(e => e.Paymentmethod)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("paymentmethod");
            entity.Property(e => e.Paymentstatus).HasColumnName("paymentstatus");

            entity.HasOne(d => d.Devotee).WithMany(p => p.Payments)
                .HasForeignKey(d => d.Devoteeid)
                .HasConstraintName("FK__payments__devote__3E52440B");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Roleid).HasName("PK__roles__CD994BF26387C53E");

            entity.ToTable("roles");

            entity.Property(e => e.Roleid).HasColumnName("roleid");
            entity.Property(e => e.Rolename)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("rolename");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Userid).HasName("PK__users__CBA1B2573BA5CDAB");

            entity.ToTable("users");

            entity.Property(e => e.Userid).HasColumnName("userid");
            entity.Property(e => e.Devoteeid).HasColumnName("devoteeid");
            entity.Property(e => e.Roleid).HasColumnName("roleid");
            entity.Property(e => e.Useremail)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("useremail");
            entity.Property(e => e.Username)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("username");
            entity.Property(e => e.Userpass)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("userpass");

            entity.HasOne(d => d.Devotee).WithMany(p => p.Users)
                .HasForeignKey(d => d.Devoteeid)
                .HasConstraintName("FK__users__devoteeid__3B75D760");

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.Roleid)
                .HasConstraintName("FK__users__roleid__3A81B327");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

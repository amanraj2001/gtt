﻿using System;
using System.Collections.Generic;

namespace que1.Models;

public partial class User
{
    public int Userid { get; set; }

    public string? Username { get; set; }

    public string? Useremail { get; set; }

    public string? Userpass { get; set; }

    public int? Roleid { get; set; }

    public int? Devoteeid { get; set; }

    public virtual Devotee? Devotee { get; set; }

    public virtual Role? Role { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace que1.Models;

public partial class Devotee
{
    public int Devoteeid { get; set; }

    public string? Firstname { get; set; }

    public string? Middlename { get; set; }

    public string? Lastname { get; set; }

    public string? Image { get; set; }

    public string? Flatnumber { get; set; }

    public string? Area { get; set; }

    public string? State { get; set; }

    public string? City { get; set; }

    public int? Pincode { get; set; }

    public string? Useremail { get; set; }

    public DateTime? Initiationdate { get; set; }

    public int? Otp { get; set; }

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    public virtual ICollection<User> Users { get; set; } = new List<User>();
}

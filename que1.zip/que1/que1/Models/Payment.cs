﻿using System;
using System.Collections.Generic;

namespace que1.Models;

public partial class Payment
{
    public int Paymentid { get; set; }

    public int? Paymentamount { get; set; }

    public bool? Paymentstatus { get; set; }

    public string? Paymentmethod { get; set; }

    public DateTime? Createddata { get; set; }

    public DateTime? Modifieddate { get; set; }

    public int? Devoteeid { get; set; }

    public virtual Devotee? Devotee { get; set; }
}

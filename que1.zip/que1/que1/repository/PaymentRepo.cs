﻿using que1.Interface;
using que1.Models;

namespace que1.repository
{
    public class PaymentRepo : GenericRepo<Payment>, Ipayment
    {
        public PaymentRepo(SpiritualContext context) : base(context)
        {
        }
    }
}

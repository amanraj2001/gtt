﻿using que1.Interface;
using que1.Models;

namespace que1.repository
{
    public class DevoteeRepo : GenericRepo<Devotee>, Idevotee
    {
        public DevoteeRepo(SpiritualContext context) : base(context)
        {
        }
    }
}

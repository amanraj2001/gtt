﻿using Microsoft.EntityFrameworkCore;
using que1.Interface;
using que1.Models;

namespace que1.repository
{
    public class GenericRepo<T> : Igeneric<T> where T : class
    {
        private readonly SpiritualContext _context;
        private readonly DbSet<T> table;

        public GenericRepo(SpiritualContext context)
        {
            _context = context;
            table = _context.Set<T>();
            
        }
        public Task add(T entity)
        {
            throw new NotImplementedException();
        }

        public async  Task Delete(T entity)
        {
           table.Remove(entity);
            await _context.SaveChangesAsync();
          
        }

        public IEnumerable<T> Getall()
        {
            return table.ToList();
        }

        public Task update(T entity, int id)
        {
            throw new NotImplementedException();
        }
    }
}

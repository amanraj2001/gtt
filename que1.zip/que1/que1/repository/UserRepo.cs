﻿using que1.Interface;
using que1.Models;

namespace que1.repository
{
    public class UserRepo : GenericRepo<User>, Iuser
    {
        public UserRepo(SpiritualContext context) : base(context)
        {
        }
    }
}

﻿namespace que1.dtos
{
    public class Otpdto
    {
        public string otp { get; set; }
    }
}

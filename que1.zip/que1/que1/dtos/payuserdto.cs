﻿namespace que1.dtos
{
    public class payuserdto
    {
        public int? Paymentamount { get; set; }

        //public bool? Paymentstatus { get; set; }

        public string? Paymentmethod { get; set; }
        public string otp { get; set; }


    }
}

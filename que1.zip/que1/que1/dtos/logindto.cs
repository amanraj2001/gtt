﻿namespace que1.dtos
{
    public class logindto
    {
        public string? Username { get; set; }
        public string? Userpass { get; set; }

    }
}
